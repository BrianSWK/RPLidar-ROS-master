# RPLidar-ROS
This is something that my team have done during the Internship to help with the descriptions mentioned in my OSDK-ROS-3.2
