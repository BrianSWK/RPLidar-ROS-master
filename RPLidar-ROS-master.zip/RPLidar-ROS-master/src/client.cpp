#include "ros/ros.h"
#include "sensor_msgs/LaserScan.h"
#include "iostream"
#include "fstream"

#define RAD2DEG(x) ((x)*180./M_PI)

using namespace std;

void scanCallback(const sensor_msgs::LaserScan::ConstPtr& scan)
{
    int count = scan->scan_time / scan->time_increment;
    ROS_INFO("I heard a laser scan %s[%d]:", scan->header.frame_id.c_str(), count);
    ROS_INFO("angle_range, %f, %f", RAD2DEG(scan->angle_min), RAD2DEG(scan->angle_max));
  
    for(int i = 0; i < count; i++) 
    {
        float degree = RAD2DEG(scan->angle_min + scan->angle_increment * i);
        ROS_INFO(": [%f, %f]", degree, scan->ranges[i]);

	int Frontfile, Backfile, Leftfile, Rightfile, FrontRightfile, FrontLeftfile;
	int z = 1;
	double F, FL, FR, B, BL, BR, L, LT, LB, R, RT, RB;
	
	if (degree > 178 && degree < 180)
	{
		F = scan->ranges[i];
		if (F >= 0 && F <= 25)
		{
		ofstream Frontfile;
		Frontfile.open ("Front.txt");
			Frontfile << F;
		  	Frontfile.close();
		}
		else
        {
            ofstream Frontfile;
            Frontfile.open("Front.txt");
            Frontfile << 25;
            Frontfile.close();
        }

	}

	if (degree > 0 && degree < 2)
	{
	B = scan->ranges[i];
 		if (B >= 0 && B <= 25)
		{
	ofstream Backfile;
	Backfile.open ("Back.txt");
			Backfile << B;
		  	Backfile.close();
		}
		else
        {
            ofstream Backfile;
            Backfile.open("Back.txt");
            Backfile << 25;
            Backfile.close();
        }

	}

	if (degree > -95  && degree < -93)
	{
	L = scan->ranges[i];
		if (L >= 0 && L <= 25)
		{
	ofstream Leftfile;
	Leftfile.open ("Left.txt");
			Leftfile << L;
		  	Leftfile.close();
		}
		else
        {
            ofstream Leftfile;
            Leftfile.open("Left.txt");
            Leftfile << 25;
            Leftfile.close();
        }

	}

	if (degree > 93  && degree < 95)
	{
	R = scan->ranges[i];
		if (R >= 0 && R <= 25)
		{
	ofstream Rightfile;
	Rightfile.open ("Right.txt");
			Rightfile << R;
		  	Rightfile.close();
		}
		else
		{
            ofstream Rightfile;
            Rightfile.open("Right.txt");
            Rightfile << 25;
            Rightfile.close();
		}
		
	}

	if (degree > 138  && degree < 140)
	{
	FR = scan->ranges[i];
		if (FR >= 0 && FR <= 25)
		{
	ofstream FrontRightfile;
	FrontRightfile.open ("FrontRight.txt");	
			FrontRightfile << FR;
			FrontRightfile.close ();

		}
		else
        {
            ofstream FrontRightfile;
            FrontRightfile.open("FrontRight.txt");
            FrontRightfile << 25;
            FrontRightfile.close();
        }

	}

	if (degree > -131  && degree < -129)
	{
	FL = scan->ranges[i];
		if (FL >= 0 && FL <= 25)
		{
	ofstream FrontLeftfile;
	FrontLeftfile.open ("FrontLeft.txt");
			FrontLeftfile << FL;
			FrontLeftfile.close ();
		}
		else
        {
            ofstream FrontLeftfile;
            FrontLeftfile.open("FrontLeft.txt");
            FrontLeftfile << 25;
            FrontLeftfile.close();
        }

	}
	
	if (degree > -46 && degree < -44)
    {
        BL = scan->ranges[i];
            if (BL >= 0 && BL <=25)
            {
                ofstream BackLeftfile;
                BackLeftfile.open("BackLeft.txt");
                BackLeftfile << BL;
                BackLeftfile.close();
            }
            else
            {
                ofstream BackLeftfile;
                BackLeftfile.open("BackLeft.txt");
                BackLeftfile << 25;
                BackLeftfile.close();
            }
    }
    
    if (degree > 54 && degree < 56)
    {
        BR = scan->ranges[i];
            if (BR >= 0 && BR <=25)
            {
                ofstream BackRightfile;
                BackRightfile.open("BackRight.txt");
                BackRightfile << BR;
                BackRightfile.close();
            }
            else
            {
                ofstream BackRightfile;
                BackRightfile.open("BackRight.txt");
                BackRightfile << 25;
                BackRightfile.close();
            }
    }


    }
}

int main(int argc, char *argv[])
{
    ros::init(argc, argv, "rplidar_node_client");
    ros::NodeHandle n;
    ros::Subscriber sub = n.subscribe<sensor_msgs::LaserScan>("/scan", 1, scanCallback);
    ros::spin();
}





